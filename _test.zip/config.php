<?php

session_start(); // Start the session to store user authentication status

$servername = '127.0.0.1';
$username = 'u354271681_testmonlss';
$password = 'Hello#@4001';
$dbname = 'u354271681_testmonks';

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
