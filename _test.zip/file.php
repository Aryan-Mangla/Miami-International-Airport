<?php
require_once "config.php";
$url = $_SERVER['REQUEST_URI'];
$urlSegments = explode('/', rtrim($url, '/'));
$pageSlug = end($urlSegments); // Get the last segment of the URL
$sql = "SELECT title, content,slug,  meta_desc, meta_cronical,meta_Keywords FROM pages WHERE slug = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $pageSlug);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    // Page found, display content
    $row = $result->fetch_assoc();
    $title = $row["slug"];
    $content = $row["content"];
    $metaDescription = $row["meta_desc"];
    $metaCanonical = $row["meta_cronical"];
    $metaKeywords = $row["meta_Keywords"];

}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="<?php echo $metaDescription ?>">
        <meta name="keywords" content="<?php echo  $metaKeywords ?>">
    <link rel="canonical" href="<?php echo htmlspecialchars($metaCanonical); ?>">
    <title><?php echo $title ?></title>
    <link href="/bootstrap.min.css" rel="stylesheet">
    <link href="/style.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.tiny.cloud/1/ebs4evfkr4f8epp30mmtuelc8xqoiktmffjcg8sr6zt11ibd/tinymce/6/tinymce.min.js" referrerpolicy="origin"></script>
    <script src="https://cdn.tiny.cloud/1/ebs4evfkr4f8epp30mmtuelc8xqoiktmffjcg8sr6zt11ibd/tinymce/6/tinymce.min.js" referrerpolicy="origin"></script>
    <script src="https://kit.fontawesome.com/efb7a73d46.js" crossorigin="anonymous"></script>

    <style>
          .breadcrumb {
            justify-content: center;
        }
    </style>
</head>
<body>
<?php 
    
    require_once "config.php";

    
?>
    <?php

   
    $url = isset($_GET['url']) ? $_GET['url'] : '';
    $urlSegments = explode('/', $url);
   
// Check for case-sensitive duplicate segments
$lowercaseSegments = array_map('strtolower', $urlSegments);
if (count($lowercaseSegments) !== count(array_unique($lowercaseSegments))) {
     header("Location: ../nopage.php");
}
    // Create a connection to the database
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
       header("Location: ../nopage.php");
    }

    // Fetch page based on URL
    $pageSlug = end($urlSegments); // Get the last segment of the URL
    $sql = "SELECT * FROM pages WHERE BINARY slug = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $pageSlug);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Page found, display content
        $row = $result->fetch_assoc();
        $pageId = $row["id"];
        $title = $row["title"];
        $design = $row["design"];
        if ($design=="Design_3"){
            include 'new_header.php';
        }else{
            include 'new_header.php';
        }
echo'<div class="container mt-5">';

        if($design == "Design_1"){
            echo "<div class='title-container'>";
            echo "<h1 class='mb-4 text-center'>$title</h1>";
            if(isset($_SESSION['email'])){

                echo "<a href='../PHP-Blog-Admin/admin/edit_page.php?id=" . urlencode($pageId) . "' class='btn'>Edit</a>";
         
                echo "<a href='../PHP-Blog-Admin/admin/delete_page.php?id=" . urlencode($pageId) . "' class='btn'>Delete</a>";
              
            }
           

            echo '<nav aria-label="breadcrumb"><ol class="breadcrumb ">';
            echo '<li class="breadcrumb-item"><a href="../index.php" class="text-dark text-decoration-none"><i class="fa-solid fa-house"></i></a></li>';
            $breadcrumbUrl = '..';
            $segmentCount = count(array_filter($urlSegments));
            foreach ($urlSegments as $index => $segment) {
                if (!empty($segment)) {
                    $breadcrumbUrl .= '/' . $segment;
                    $isLastSegment = ($index === $segmentCount - 1);
                    $class = $isLastSegment ? 'theme-color fw-bolder' : 'text-dark';
                    echo '<li class="breadcrumb-item"><a class="text-decoration-none ' . $class . '" href="' . $breadcrumbUrl . '">' . ucfirst($segment) . '</a></li>';
                }
            }
            echo '</ol></nav>';
            echo "</div>"; // Close title-container
            $content = $row["content"];
            $image = $row["image"]; // Assuming you have an image column in your table
      
            echo "<p>$content</p>";

            // Check if the page has child pages
            $childSql = "SELECT * FROM pages WHERE  parent_id = ?";
            $childStmt = $conn->prepare($childSql);
            $childStmt->bind_param("i", $pageId);
            $childStmt->execute();
            $childResult = $childStmt->get_result();
    
            if ($childResult->num_rows > 0) {
                // Page has child pages, display the links to the child pages
               
                echo "<div class='row'>";
    
                $childCount = 0;
                while ($childRow = $childResult->fetch_assoc()) {
                    $childTitle = $childRow["title"];
                    $childSlug = $childRow["slug"];
                    $childImage = $childRow["image"]; // Assuming you have an image column for child pages
                    $childDate =$childRow["date"];
                    //  $name = $_SESSION['Name'];
                    $childUrl = generatePageUrl($childRow["id"]);
    
                    if ($childCount > 0 && $childCount % 3 == 0) {
                        echo '</div><div class="row mt-4">';
                    }
    
                    echo "<div class='col-md-4 mb-4'>";
                    echo "<a href='$childUrl' class='text-decoration-none text-dark ' >";
                    echo "<div class='card border-0 h-100' style='box-shadow: rgba(100, 100, 111, 0.2) 0px 7px 29px 0px;'>";
                    if ($childImage) {
                        echo "<img src='$childImage' class='card-img-top p-2' alt='$childTitle'>";
                    }
                    echo "<div class='card-body'>";
                    echo "<h5 class='card-title'>$childTitle</h5>";
                    echo "<small class='badge theme-bg my-2'>$childDate</small>";
                    // echo "<small class='badge theme-bg my-2'>$childName</small>";
                   echo"</a>";
                    echo "</div></div></div>";
    
                    $childCount++;
                }
    
                echo '</div>'; // Close the last row
    
                // Pagination
                $totalPages = ceil($childCount / 12);
                if ($totalPages > 1) {
                    echo '<nav><ul class="pagination justify-content-center mt-4">';
                    for ($i = 1; $i <= $totalPages; $i++) {
                        echo "<li class='page-item'><a class='page-link' href='?url=$url&page=$i'>$i</a></li>";
                    }
                    echo '</ul></nav>';
                }
            }
    
            $childStmt->close();
        
        }
// Design with side bar left
elseif($design == "Design_3"){

    echo '<div class="row my-5">';
    
    // Right Content
    echo '<div class="col-md-9">';
    echo '<div class="container">';
        // Add the specified code for the child page content
        echo "<div class='title-container'>";
            echo "<h1 class='mb-4 text-center'>$title</h1>";
            echo '<nav aria-label="breadcrumb"><ol class="breadcrumb">';
            echo '<li class="breadcrumb-item"><a href="../index.php" class="text-dark text-decoration-none"><i class="fa-solid fa-house"></i></a></li>';
            $breadcrumbUrl = '/';
            $segmentCount = count(array_filter($urlSegments));
            foreach ($urlSegments as $index => $segment) {
                if (!empty($segment)) {
                    $breadcrumbUrl .= '../' . $segment;
                    $isLastSegment = ($index === $segmentCount - 1);
                    $class = $isLastSegment ? 'theme-color fw-bolder' : 'text-dark';
                    echo '<li class="breadcrumb-item"><a class="text-decoration-none ' . $class . '" href="' . $breadcrumbUrl . '">' . ucfirst($segment) . '</a></li>';
                }
            }
            echo '</ol></nav>';
        echo "</div>"; // Close title-container
        
        $content = $row["content"];
        echo "<p>$content</p>";
        $image = $row["image"]; // Assuming you have an image column in your table
        if ($image) {
            echo '<div class="container">';
            echo "<img src='$image' style='height: 100%; width: 100%; border-radius: 5em;' class='img-fluid mb-4' alt='" . $row["title"] . "'>";
            echo '</div>';
        }
    echo '</div>';
        // Comment section start
    ?>

    <div class="container mt-5" >
        <div class="row">
            <div class="col-md-8" style="width:100%">
                <?php
                $id = 11; //Specially for blog we have commnet section
                ?>
                <!-- Comment Form -->
               <form class="p-4 rounded-3" action="comments.php" method="POST" style="box-sizing: border-box; box-shadow: rgba(50, 50, 93, 0.25) 0px 13px 27px -5px, rgba(0, 0, 0, 0.3) 0px 8px 16px -8px;">
    <div class="form-group">
        <label for="name">Your Name:</label>
        <input type="text" id="name" name="name" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="rating">Rating:</label>
        <div class="star-rating">
            <input type="radio" id="star5" name="rating" value="5"><label for="star5" title="5 stars">★</label>
            <input type="radio" id="star4" name="rating" value="4"><label for="star4" title="4 stars">★</label>
            <input type="radio" id="star3" name="rating" value="3"><label for="star3" title="3 stars">★</label>
            <input type="radio" id="star2" name="rating" value="2"><label for="star2" title="2 stars">★</label>
            <input type="radio" id="star1" name="rating" value="1"><label for="star1" title="1 star">★</label>
        </div>
    </div>
    <div class="form-group">
        <label for="comment">Enter your comment:</label>
        <textarea id="comment" name="comment" class="form-control"></textarea>
    </div>
    <input type="hidden" name="id" value="<?php echo $id; ?>">
    <button type="submit" class="btn btn-primary my-3">Submit</button>
</form>
    
                <!-- Comments Section -->
                <div id="commentsSection" class="mt-5 p-3 rounded-3" style="box-sizing: border-box; box-shadow: rgba(50, 50, 93, 0.25) 0px 13px 27px -5px, rgba(0, 0, 0, 0.3) 0px 8px 16px -8px;">
                    <h4>Comments:</h4>
                    <div id="commentsList">
                        <?php
                        // Fetch approved comments for the specific event from the database
                        $sql = "SELECT name, rating, comment FROM comment_section WHERE approved = TRUE ORDER BY date DESC";
                        $result = $conn->query($sql);

                        if ($result->num_rows > 0) {
                            // Output data of each row
                            while($row = $result->fetch_assoc()) {
                                echo '<div class="card mb-3">';
                                echo '<div class="card-body">';
                                echo '<h5 class="card-title">' . htmlspecialchars($row['name']) . '</h5>';
                                echo '<h6 class="card-subtitle mb-2 text-muted ">Rating: ' . str_repeat('★', $row['rating']) . str_repeat('☆', 5 - $row['rating']) . '</h6>';
                                echo '<p class="card-text">' . htmlspecialchars($row['comment']) . '</p>';
                                echo '</div>';
                                echo '</div>';
                            }
                        } else {
                            echo '<p>No comments yet. Be the first to comment!</p>';
                        }

                       
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php
    // Comment section end
    echo '</div>';

    // Left Sidebar
    echo '<div class="col-md-3">';
    echo'<div style="position: sticky;
    top: 90px;"> ';
    // Fetch parent ID of the current child page
    $parentSql = "SELECT parent_id FROM pages WHERE id =?";
    $parentStmt = $conn->prepare($parentSql);
    if ($parentStmt === false) {
        die("Prepare failed: ". htmlspecialchars($conn->error));
    }

    $parentStmt->bind_param("i", $pageId);
    if (!$parentStmt->execute()) {
        die("Execute failed: ". htmlspecialchars($parentStmt->error));
    }

    $parentResult = $parentStmt->get_result();
    if ($parentResult === false) {
        die("Get result failed: ". htmlspecialchars($parentStmt->error));
    }

    if ($parentResult->num_rows > 0) {
        $parentRow = $parentResult->fetch_assoc();
        $parentId = $parentRow['parent_id'];

        // Now fetch other child pages of this parent
        $childSql = "SELECT * FROM pages WHERE parent_id =? AND id!=?";
        $childStmt = $conn->prepare($childSql);
        if ($childStmt === false) {
            die("Prepare failed: ". htmlspecialchars($conn->error));
        }

        $childStmt->bind_param("ii", $parentId, $pageId);
        if (!$childStmt->execute()) {
            die("Execute failed: ". htmlspecialchars($childStmt->error));
        }

        $childResult = $childStmt->get_result();
        if ($childResult === false) {
            die("Get result failed: ". htmlspecialchars($childStmt->error));
        }

        if ($childResult->num_rows > 0) {
            // Page has sibling child pages, display the links to the sibling child pages
            echo "<h2 class='mt-5'>Other Blogs</h2>";
            echo "<div class='row'>";

            $childCount = 0;
            while ($childRow = $childResult->fetch_assoc()) {
                if ($childCount >= 6) {
                    break;
                }

                $childTitle = htmlspecialchars($childRow["title"]);
                $childSlug = htmlspecialchars($childRow["slug"]);
                $childImage = htmlspecialchars($childRow["image"]); // Assuming you have an image column for child pages
                $childUrl = generatePageUrl($childRow["id"]);

                echo "<div class='col-md-12 mb-4'>";
                echo "<a href='../$childUrl' class='text-decoration-none text-dark'>";
                echo "<div class='card border-0' style='box-shadow: rgba(100, 100, 111, 0.2) 0px 7px 29px 0px;'>";
                if ($childImage) {
                    echo "<img src='$childImage' class='card-img-top p-2' alt='$childTitle'>";
                }
                echo "<div class='card-body'>";
                echo "<h5 class='card-title'>$childTitle</h5>";
                echo "</div></div></a></div>";

                $childCount++;
            }
            echo '</div>';

            if ($childResult->num_rows > 6) {
                echo "<div class='text-center mt-4'>";
                echo "<a href='". generatePageUrl($childRow["id"]). "' class='btn btn-primary'>Load More</a>";
                echo "</div>";
            }
        } else {
            echo "<p>No sibling pages found.</p>";
        }
    } else {
       header("Location: nopage.php");
    }
    echo '</div>';
    echo '</div>'; // End of row
echo'</div>';

}


        
        
        else{
            echo "<div class='title-container'>";
            echo "<h1 class='mb-4 text-center'>$title</h1>";
            echo '<nav aria-label="breadcrumb"><ol class="breadcrumb ">';
          echo '<li class="breadcrumb-item"><a href="../index.php" class="text-dark text-decoration-none"><i class="fa-solid fa-house"></i></a></li>';
            $breadcrumbUrl = '/';
            $segmentCount = count(array_filter($urlSegments));
            foreach ($urlSegments as $index => $segment) {
                if (!empty($segment)) {
                    $breadcrumbUrl .= '/' . $segment;
                    $isLastSegment = ($index === $segmentCount - 1);
                    $class = $isLastSegment ? 'theme-color fw-bolder' : 'text-dark';
                    echo '<li class="breadcrumb-item"><a class="text-decoration-none ' . $class . '" href="' . $breadcrumbUrl . '">' . ucfirst($segment) . '</a></li>';
                }
            }
            echo '</ol></nav>';
            echo "</div>"; // Close title-container
            $content = $row["content"];
            echo'I am in 2';
            $image = $row["image"]; // Assuming you have an image column in your table
      
            echo "<p>$content</p>";
            if ($image) {
                echo'<div class="container"> ';
                echo "<img src='$image' style='height: 100%;
                width: 100%;
                border-radius: 5em;' class='img-fluid mb-4' alt='" . $row["title"] . "'>";
                echo"</div>'";
            }

   
        }
        }else {
            // Page not found
           header("Location: ../nopage.php");
        }
      

    $stmt->close();
    // $conn->close();

    function generatePageUrl($page_id) {
        global $conn;

        $segments = [];
        $current_id = $page_id;

        while ($current_id !== null) {
            $stmt = $conn->prepare("SELECT slug, parent_id FROM pages WHERE id = ?");
            $stmt->bind_param("i", $current_id);
            $stmt->execute();
            $stmt->bind_result($slug, $parent_id);
            $stmt->fetch();
            $segments[] = $slug;
            $current_id = $parent_id;
            $stmt->close();
        }

        $segments = array_reverse($segments);
        return implode('/', $segments);
    }
    ?>
</div>
 <!-- Font Awesome JS -->
 <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/js/all.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.min.js" integrity="sha384-cuYeSxntonz0PPNlHhBs68uyIAVpIIOZZ5JqeqvYYIcEL727kskC66kF92t6Xl2V" crossorigin="anonymous"></script>

<?php include 'myfooter.php'; ?>
</body>
</html>
