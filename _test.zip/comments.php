<?php
include 'config.php';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' ) {
    
    $comment = $conn->real_escape_string($_POST['comment']);
    $id = 11 // Assuming 'id' is the identifier of the comment
    $name = $conn->real_escape_string($_POST['name']);
    $rating = intval($_POST['rating']);

    // Insert comment into the database using prepared statements
    $stmt = $conn->prepare("INSERT INTO comment_section (comment, id, name, rating) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("sisi", $comment, $id, $name, $rating);
    
    if ($stmt->execute()) {
        header("Location: index.php?id=$id&status=success");
    } else {
        header("Location: index.php?id=$id&status=error");
    }
    exit(); // Ensure no further processing is done after redirect
}

$conn->close();
?>