
<header class="sticky-top">
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light" aria-label="Main Navbar" style="background-color: #fafafa;box-shadow: rgba(0, 0, 0, 0.1) 0px 4px 12px;">
        <div class="container px-lg-4">
            <a class="navbar-brand" href="../index.php">
                <img src="..\Pic\atlanta-international-logo.png" class="img542"  alt="Atlanta Airport">
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNavbar" aria-controls="mainNavbar" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-end" id="mainNavbar">
                <ul class="navbar-nav">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle link-dark" href="#" id="navbarDropdown1" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Flights
                        </a>
                        <ul class="dropdown-menu p-3" aria-labelledby="navbarDropdown2" style="width: 15em!important;">
                            <li>
                                <a href="flights-arrivals" class="text-decoration-none text-dark">Arrivals</a>
                            </li>
                            <li>
                                <a href="flights-departures" class="text-decoration-none text-dark">Departures</a>
                            </li>
                            <li>
                                <a href="flights-connections" class="text-decoration-none text-dark">Connections</a>
                            </li>
                        </ul>
                    </li>
                   
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle link-dark" href="#" id="navbarDropdown2" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Terminals
                        </a>
                        <ul class="dropdown-menu p-3" aria-labelledby="navbarDropdown2" style="width: 15em!important;">
                            <li>
                                <a href="terminal" class="text-decoration-none text-dark">Terminal</a>
                            </li>
                            <li>
                                <a href="domestic-terminal" class="text-decoration-none text-dark">Domestic Terminal</a>
                            </li>
                            <li>
                                <a href="international-terminal" class="text-decoration-none text-dark">International Terminal</a>
                            </li>
                        </ul>
                    </li>
                    <!-- Category: Transportation -->
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle link-dark" href="#" id="navbarDropdown3" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Transportations
                        </a>
                        <ul class="dropdown-menu p-3 test54" aria-labelledby="navbarDropdown3">
                            <!-- Row 1 -->
                            <div class="row">
                                <div class="col-md-4">
                                    <a href="transportation" class="text-decoration-none text-dark">Transportations</a>
                                </div>
                                <div class="col-md-4">
                                    <a href="ground-transportation" class="text-decoration-none text-dark">Ground Transportations</a>
                                </div>
                                <div class="col-md-4">
                                    <a href="airport-taxi" class="text-decoration-none text-dark">Airport Taxi</a>
                                </div>
                            </div>
                            <!-- Row 1 end-->
                            <!-- Row 2 -->
                            <div class="row my-2">
                                <div class="col-md-4">
                                    <a href="airport-train" class="text-decoration-none text-dark">Airport Train</a>
                                </div>
                                <div class="col-md-4">
                                    <a href="airport-bus" class="text-decoration-none text-dark">Airport Bus</a>
                                </div>
                                <div class="col-md-4">
                                    <a href="shared-ride-shuttle" class="text-decoration-none text-dark">Shared Ride Shuttle</a>
                                </div>
                            </div>
                            <!-- Row 2 end-->
                            <!-- Row 3 -->
                            <div class="row my-2">
                                <div class="col-md-4">
                                    <a href="airport-shuttle" class="text-decoration-none text-dark">Airport Shuttles</a>
                                </div>
                                <div class="col-md-4">
                                    <a href="airport-transportation" class="text-decoration-none text-dark">Airport Transportation</a>
                                </div>
                                <div class="col-md-4">
                                    <a href="limo-service" class="text-decoration-none text-dark">Limo Service</a>
                                </div>
                            </div>
                            <!-- Row 3 end-->
                        </ul>
                    </li>
                    <!-- Category: Transportation End -->

                    <!-- Category: Parking -->
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle link-dark" href="#" id="navbarDropdown4" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Parking
                        </a>
                        <ul class="dropdown-menu p-3 test55" aria-labelledby="navbarDropdown4">
                            <!-- Row 1 -->
                            <div class="row">
                                <div class="col-md-4">
                                    <a href="parking" class="text-decoration-none text-dark">Parking</a>
                                </div>
                                <div class="col-md-4">
                                    <a href="parking-rates" class="text-decoration-none text-dark">Parking Rates</a>
                                </div>
                                <div class="col-md-4">
                                    <a href="overnight-parking" class="text-decoration-none text-dark">Overnight Parking</a>
                                </div>
                               
                            </div>
                            <!-- Row 1 end-->
                            <!-- Row 2 -->
                            <div class="row my-2">
                                <div class="col-md-4">
                                    <a href="parking-lots" class="text-decoration-none text-dark">Parking Lots</a>
                                </div>
                                <div class="col-md-4">
                                    <a href="off-site-parking" class="text-decoration-none text-dark">Off Site Parking</a>
                                </div>
                                <div class="col-md-4">
                                    <a href="domestic-parking" class="text-decoration-none text-dark">Domestic Parking</a>
                                </div>
                               
                            </div>
                            <!-- Row 2 end-->
                            <!-- Row 3 -->
                            <div class="row my-2">
                                <div class="col-md-4">
                                    <a href="daily-parking" class="text-decoration-none text-dark">Daily Parking</a>
                                </div>
                                <div class="col-md-4">
                                    <a href="short-term-parking" class="text-decoration-none text-dark">Short Term Parking</a>
                                </div>
                                <div class="col-md-4">
                                    <a href="economy-parking" class="text-decoration-none text-dark">Economy Parking</a>
                                </div>
                               
                            </div>
                            <!-- Row 3 end-->
                            <!-- Row 4 -->
                            <div class="row my-2">
                                <div class="col-md-4">
                                    <a href="affordable-parking" class="text-decoration-none text-dark">Affordable Parking</a>
                                </div>
                                <div class="col-md-4">
                                    <a href="north-terminal-parking" class="text-decoration-none text-dark">North Terminal Parking</a>
                                </div>
                                <div class="col-md-4">
                                    <a href="south-terminal-parking" class="text-decoration-none text-dark">South Terminal Parking</a>
                                </div>
                              
                            </div>
                            <!-- Row 4 end-->
                             <!-- Row 5 -->
                             <div class="row">
                             <div class="col-md-4">
                                    <a href="cell-phone-lot" class="text-decoration-none text-dark">Cell Phone Lot</a>
                                </div>
                                <div class="col-md-4">
                                    <a href="international-airport-parking" class="text-decoration-none text-dark">International Airport Parking</a>
                                </div>
                                <div class="col-md-4">
                                    <a href="overnight-parking" class="text-decoration-none text-dark">Overnight Parking</a>
                                </div>
                               
                            </div>
                            <!-- Row 5 end-->
                            <!-- Row 6 -->
                            <div class="row">
                            <div class="col-md-4">
                                    <a href="long-term-parking" class="text-decoration-none text-dark">Long Term Parking</a>
                                </div>
                                <div class="col-md-4">
                                    <a href="hourly-parking" class="text-decoration-none text-dark">Hourly Parking</a>
                                </div>
                            </div>
                            <!-- Row 6 end-->
                        </ul>
                        
                    <li class="nav-item">
                        <a class="nav-link link-dark" href="../blogs">Blogs</a>
                    </li>
                    </li>
                    <!-- Category: Parking End -->
                </ul>
            </div>
        </div>
    </nav>
</header>
