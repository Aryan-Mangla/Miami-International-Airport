(function() {
    tinymce.PluginManager.add('bootstrap_columns', function(editor, url) {
        // Add button for a row with two equal columns
        editor.ui.registry.addButton('two_col', {
            text: '2 Columns',
            icon: 'table', // Use an appropriate icon from TinyMCE or custom
            onAction: function() {
                editor.insertContent('<div class="row"><div class="col-md-6">Column 1</div><div class="col-md-6">Column 2</div></div>');
            }
        });

        // Add button for a row with three equal columns
        editor.ui.registry.addButton('three_col', {
            text: '3 Columns',
            icon: 'table', // Use an appropriate icon from TinyMCE or custom
            onAction: function() {
                editor.insertContent('<div class="row"><div class="col-md-4">Column 1</div><div class="col-md-4">Column 2</div><div class="col-md-4">Column 3</div></div>');
            }
        });

        // Add more buttons as needed for different column configurations
    });
})();