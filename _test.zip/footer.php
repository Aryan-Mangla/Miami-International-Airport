<footer class="text-dark mt-5" style="background-color: #fafafa;box-shadow: rgba(0, 0, 0, 0.1) 0px -4px 12px;">
    <div class="container" style="background-color: #fafafa;">
      <div class="row row-cols-2 row-cols-lg-4 g-4 pb-5 mt-5">
        <div class="col-12 mb-3">
        <a class="navbar-brand" href="index.php">
                <img src="Pic/atlanta-international-logo.png" style="width:15em;"  alt="Atlanta Airport">
            </a>
        </div>
        <!-- <div class="col mb-3">
          <h5 class="mb-3 fw-bold fs-4">Handy Links</h5>
          <ul class="nav flex-column gap-2">
            <li class="nav-item mb-2">
              <a href="index.php" class="nav-link p-0 anchor ">Home</a>
            </li>
            <li class="nav-item mb-2">
              <a href="about-us" class="nav-link p-0 anchor">About Us</a>
            </li>
            
           
            <li class="nav-item mb-2">
              <a href="contact-us" class="nav-link p-0 anchor">Contact</a>
            </li>
            <li class="nav-item mb-2">
              <a href="blogs" class="nav-link p-0 anchor">Blogs</a>
            </li>
          </ul>
        </div> -->
        <div class="col mb-2">
          <h5 class="mb-3 fw-bold fs-4">Flights</h5>
          <ul class="nav flex-column gap-2">
            <li class="nav-item mb-2">
              <a href="flights-arrivals" class="nav-link p-0 anchor">Arrivals</a>
            </li>
            <li class="nav-item mb-2">
              <a href="flights-departures" class="nav-link p-0 anchor">Departures</a>
            </li>
            <li class="nav-item mb-2">
              <a href="flights-connections" class="nav-link p-0 anchor">Connections</a>
            </li>
          </ul>
        </div>
        <div class="col mb-2">
          <h5 class="mb-3 fw-bold fs-4">Airport Guide</h5>
          <ul class="nav flex-column gap-2">
            <li class="nav-item mb-2">
              <a href="terminal" class="nav-link p-0 anchor">Terminals</a>
            </li>
            <li class="nav-item mb-2">
              <a href="transportation" class="nav-link p-0 anchor">Transportation</a>
            </li>
            <li class="nav-item mb-2">
              <a href="parking" class="nav-link p-0 anchor">Parking</a>
            </li>
            <li class="nav-item mb-2">
              <a href="customer-service" class="nav-link p-0 anchor">Customer Service</a>
            </li>
            <li class="nav-item mb-2">
              <a href="lounges" class="nav-link p-0 anchor">Lounge</a>
            </li>
            <li class="nav-item mb-2">
              <a href="hotels" class="nav-link p-0 anchor">Hotels</a>
            </li>
          </ul>
        </div>

        <div class="col mb-2">
            <h5 class="mb-3 fw-bold fs-4">Transportation</h5>
            <ul class="nav flex-column gap-2">
              <li class="nav-item mb-2">
               <a href="ground-transportation" class="nav-link p-0 anchor">Ground Transportations</a>
              </li>
              <li class="nav-item mb-2">
               <a href="airport-taxi" class="nav-link p-0 anchor">Airport Taxi</a>
              </li>
              <li class="nav-item mb-2">
                <a href="airport-train" class="nav-link p-0 anchor">Airport Train</a>
              </li>
              <li class="nav-item mb-2">
                <a href="shared-ride-shuttle" class="nav-link p-0 anchor">Shared Ride Shuttle</a>
              </li>
              <li class="nav-item mb-2">
                <a href="airport-shuttle" class="nav-link p-0 anchor">Airport Shuttles</a>
              </li>
              <li class="nav-item mb-2">
                <a href="airport-transportation" class="nav-link p-0 anchor">Airport Transportation</a>
              </li>
              <li class="nav-item mb-2">
                <a href="limo-service" class="nav-link p-0 anchor">Limo Service</a>
              </li>
            </ul>
          </div>
      </div>
    </div>
  </footer>