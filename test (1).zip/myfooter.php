<footer class="text-dark mt-5" style="background-color: #fafafa;box-shadow: rgba(0, 0, 0, 0.1) 0px -4px 12px;">
    <div class="container" style="background-color: #fafafa;">
      <div class="row row-cols-2 row-cols-lg-4 g-4 pb-5 mt-5">
        <div class="col-12 mb-3">
        <a class="navbar-brand" href="../index.php">
                <img src="..\Pic\atlanta-international-logo.png" class="img542"  alt="Atlanta Airport">
            </a>
        </div>
        <!-- <div class="col mb-3">
          <h5 class="mb-3 fw-bold fs-4">Handy Links</h5>
          <ul class="nav flex-column gap-2">
            <li class="nav-item mb-2">
              <a href="index.php" class="nav-link p-0 link-dark ">Home</a>
            </li>
            <li class="nav-item mb-2">
              <a href="about-us" class="nav-link p-0 link-dark">About Us</a>
            </li>
            
           
            <li class="nav-item mb-2">
              <a href="contact-us" class="nav-link p-0 link-dark">Contact</a>
            </li>
            <li class="nav-item mb-2">
              <a href="blogs" class="nav-link p-0 link-dark">Blogs</a>
            </li>
          </ul>
        </div> -->
        <div class="col mb-2">
          <h5 class="mb-3 fw-bold fs-4">Flights</h5>
          <ul class="nav flex-column gap-2">
            <li class="nav-item mb-2">
              <a href="flights-arrivals" class="nav-link p-0 link-dark">Arrivals</a>
            </li>
            <li class="nav-item mb-2">
              <a href="flights-departures" class="nav-link p-0 link-dark">Departures</a>
            </li>
            <li class="nav-item mb-2">
              <a href="flights-connections" class="nav-link p-0 link-dark">Connections</a>
            </li>
          </ul>
        </div>
        <div class="col mb-2">
          <h5 class="mb-3 fw-bold fs-4">Airport Guide</h5>
          <ul class="nav flex-column gap-2">
            <li class="nav-item mb-2">
              <a href="terminal" class="nav-link p-0 link-dark">Terminals</a>
            </li>
            <li class="nav-item mb-2">
              <a href="transportation" class="nav-link p-0 link-dark">Transportation</a>
            </li>
            <li class="nav-item mb-2">
              <a href="parking" class="nav-link p-0 link-dark">Parking</a>
            </li>
            <li class="nav-item mb-2">
              <a href="customer-service" class="nav-link p-0 link-dark">Customer Service</a>
            </li>
            <li class="nav-item mb-2">
              <a href="lounges" class="nav-link p-0 link-dark">Lounge</a>
            </li>
            <li class="nav-item mb-2">
              <a href="hotels" class="nav-link p-0 link-dark">Hotels</a>
            </li>
          </ul>
        </div>

        <div class="col mb-2">
            <h5 class="mb-3 fw-bold fs-4">Transportation</h5>
            <ul class="nav flex-column gap-2">
              <li class="nav-item mb-2">
               <a href="ground-transportation" class="nav-link p-0 link-dark">Ground Transportations</a>
              </li>
              <li class="nav-item mb-2">
               <a href="airport-taxi" class="nav-link p-0 link-dark">Airport Taxi</a>
              </li>
              <li class="nav-item mb-2">
                <a href="airport-train" class="nav-link p-0 link-dark">Airport Train</a>
              </li>
              <li class="nav-item mb-2">
                <a href="shared-ride-shuttle" class="nav-link p-0 link-dark">Shared Ride Shuttle</a>
              </li>
              <li class="nav-item mb-2">
                <a href="airport-shuttle" class="nav-link p-0 link-dark">Airport Shuttles</a>
              </li>
              <li class="nav-item mb-2">
                <a href="airport-transportation" class="nav-link p-0 link-dark">Airport Transportation</a>
              </li>
              <li class="nav-item mb-2">
                <a href="limo-service" class="nav-link p-0 link-dark">Limo Service</a>
              </li>
            </ul>
          </div>
      </div>
    </div>
  </footer>