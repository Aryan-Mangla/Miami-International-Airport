
<?php 

 
require_once "myconfig.php";


// Check if the 'id' GET parameter is set
if (isset($_GET['id'])) {
    // Sanitize the ID parameter to prevent SQL injection
    $airline_id = intval($_GET['id']);

    // Prepare the SQL DELETE statement
    $sql = "DELETE FROM airline_blog WHERE airline_id = ?";

    if ($stmt = $conn->prepare($sql)) {
        // Bind the airline_id parameter to the SQL statement
        $stmt->bind_param("i", $airline_id);

        // Attempt to execute the prepared statement
        if ($stmt->execute()) {
            echo "<script>alert('Blog Deleted Successfully');</script>";
        } else {
            echo "<script>alert('Error Deleting blog');</script>";
        }

        // Close the statement
        $stmt->close();
    } else {
        echo "Error preparing the statement: ";
    }
} else {
    echo "<script>alert('Error: No Id parameter Passed');</script>";
}

// Close the connection
$conn->close();
?>
