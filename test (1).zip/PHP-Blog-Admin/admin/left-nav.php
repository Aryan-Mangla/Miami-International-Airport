<nav class="navbar navbar-default navbar-static-top m-b-0">
            <div class="navbar-header"> <a class="navbar-toggle hidden-sm hidden-md hidden-lg " href="javascript:void(0)" data-toggle="collapse" data-target=".navbar-collapse"><i class="ti-menu"></i></a>
                <div class="top-left-part d-flex justify-content-center"><a class="logo" href="index.php"><span class="hidden-xs"><b>Dashboard</b></span></a></div>
                <ul class="nav navbar-top-links navbar-left hidden-xs">
                    <li><a href="javascript:void(0)" class="open-close hidden-xs waves-effect waves-light"><i class="icon-arrow-left-circle ti-menu"></i></a></li>
                   
                </ul>
               
            </div>
            <!-- /.navbar-header -->
            <!-- /.navbar-top-links -->
            <!-- /.navbar-static-side -->
        </nav>
<div class="navbar-default sidebar" role="navigation">
            <div class="sidebar-nav navbar-collapse slimscrollsidebar">
                <ul class="nav" id="side-menu">
                    <li class="sidebar-search hidden-sm hidden-md hidden-lg">
                        <!-- input-group -->
                        <div class="input-group custom-search-form">
                            <input type="text" class="form-control" placeholder="Search..."> <span class="input-group-btn">
                            <button class="btn btn-default" type="button"> <i class="fa fa-search"></i> </button>
                            </span> 
                        </div>
                        <!-- /input-group -->
                    </li>
                    <li class="user-pro">
                        <a href="#" class="waves-effect"> <span class="hide-menu"> Account<span class="fa arrow"></span></span>
                        </a>
                        <ul class="nav nav-second-level">
                            <li><a href="settings.php"><i class="ti-settings"></i> Account Setting</a></li>
                            <li><a href="functions/logout.php"><i class="fa fa-power-off"></i> Logout</a></li>
                        </ul>
                    </li>
                <li class="nav-small-cap m-t-10">--- Main Menu</li>
             <li> <a href="index.php" class="waves-effect active"><i class="linea-icon linea-basic fa-fw" data-icon="v"></i> <span class="hide-menu"> Dashboard </a>
                    </li>
                    <li> <a href="#" class="waves-effect"><i data-icon="&#xe00b;" class="linea-icon linea-basic fa-fw"></i> <span class="hide-menu">Blog<span class="fa arrow"></span></span></a>
                        <ul class="nav nav-second-level">
                            <li><a href="posts.php">All Posts</a></li>
                            <li><a href="new-post.php">Create Post</a></li>
                        </ul>
                    </li>
                    <li> <a href="#" class="waves-effect"><i data-icon="&#xe00b;" class="linea-icon linea-basic fa-fw"></i> <span class="hide-menu">Pages<span class="fa arrow"></span></span></a>
                        <ul class="nav nav-second-level">
                            <li><a href="mypages.php">All Pages</a></li>
                            <li><a href="new-page.php">Add Page</a></li>
                        </ul>
                    </li>
                    
                    <li><a href="comments.php" class="waves-effect">Comments</a>
                    </li>
                  

              <?php    
             
             $role_query = "SELECT role FROM `admin` WHERE email='$email'";
             $result_role = mysqli_query($conn, $role_query);

             if ($result_role){
                $row = mysqli_fetch_assoc($result_role); // Fetch the row from the database
            
                $role = $row['role']; // Assign the role from the database to the session
                
            }
if($role == "admin") {
    echo '<li> 
            <a href="#" class="waves-effect">
                <i data-icon="H" class="linea-icon linea-basic fa-fw"></i> 
                <span class="hide-menu">Access<span class="fa arrow"></span></span>
            </a>
            <ul class="nav nav-second-level">
                <li><a href="users.php">Administrators</a></li>
                <li><a href="new-user.php">Create Admin</a></li>
            </ul>
        </li>';
}
?>

                          
                     <li class="nav-small-cap">--- Other</li>

                    
                    
                    <li><a href="functions/logout.php" class="waves-effect"><i class="icon-logout fa-fw"></i> <span class="hide-menu">Log out</span></a></li>
                   
                </ul>
            </div>
        </div>