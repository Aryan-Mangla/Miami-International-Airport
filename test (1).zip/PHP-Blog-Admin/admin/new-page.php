<?php
ob_start();
require_once "functions/myconfig.php";

function createPage($title, $content, $slug, $meta_desc, $meta_keywords, $meta_cronical, $date, $design, $target_file_db, $parent_id = null) {
    global $conn;

    $stmt = $conn->prepare("INSERT INTO pages (title, content, parent_id, slug, meta_desc, meta_keywords, meta_cronical, date, design, image) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssisssssss", $title, $content, $parent_id, $slug, $meta_desc, $meta_keywords, $meta_cronical, $date, $design, $target_file_db);

    // Execute the statement
    if ($stmt->execute()) {
        $page_id = $stmt->insert_id; // Get the ID of the new page
        $page_url = generatePageUrl($page_id);
        echo "New page created successfully. URL: <a href='$page_url'>$page_url</a>";
        return $page_url; // Return the URL of the new page
    } else {
        echo "Error: " . $stmt->error;
        return false;
    }

    $stmt->close();
}

function generatePageUrl($page_id) {
    global $conn;

    $segments = [];
    $current_id = $page_id;

    // Fetch page and parent details to build the URL
    while ($current_id !== null) {
        $stmt = $conn->prepare("SELECT slug, parent_id FROM pages WHERE id = ?");
        $stmt->bind_param("i", $current_id);
        $stmt->execute();
        $stmt->bind_result($slug, $parent_id);
        $stmt->fetch();
        $segments[] = $slug;
        $current_id = $parent_id;
        $stmt->close();
    }

    $segments = array_reverse($segments);
    return implode('/', $segments);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'];
    $content = $_POST['content'];
    $slug1 = $_POST['slug'];
    $slug = strtolower($slug1);
    $meta_desc = $_POST['meta_desc'];
    $meta_keywords = $_POST['meta_Keywords'];
    $meta_cronical = $_POST['meta_cronical'];
    $date = $_POST['date'];
    $design = $_POST['design'];
    
    $image = $_FILES['image']['name']; // Assuming you handle file uploads elsewhere in your code
    $parent_id = !empty($_POST['parent_id']) ? (int)$_POST['parent_id'] : null;

    // Handle file upload
    $target_dir = "../../Pic/uploaded/";
    $target_db = "/airlines/Pic/uploaded/";
    $target_file = $target_dir . basename($_FILES["image"]["name"]);
    $target_file_db = $target_db . basename($_FILES["image"]["name"]);
    
    if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
        echo "The file " . basename($_FILES["image"]["name"]) . " has been uploaded.";
    } else {
        echo "Sorry, there was an error uploading your file.";
    }

    createPage($title, $content, $slug, $meta_desc, $meta_keywords, $meta_cronical, $date, $design, $target_file_db, $parent_id);
}
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Page</title>
    <link rel="stylesheet" href="bootstrap.min.css">
    <!-- Place the first <script> tag in your HTML's <head> -->
<script src="https://cdn.tiny.cloud/1/ebs4evfkr4f8epp30mmtuelc8xqoiktmffjcg8sr6zt11ibd/tinymce/7/tinymce.min.js" referrerpolicy="origin"></script>
<script>
 
 tinymce.init({
            selector: 'textarea',
            plugins: 'anchor autolink charmap codesample emoticons image link lists media searchreplace table visualblocks wordcount ',
            toolbar: 'undo redo | blocks fontfamily fontsize | bold italic underline strikethrough | link image media table mergetags | addcomment showcomments | spellcheckdialog a11ycheck typography | align lineheight | checklist numlist bullist indent outdent | emoticons charmap | removeformat',
            tinycomments_mode: 'embedded',
            tinycomments_author: 'Author name',
            mergetags_list: [
                { value: 'First.Name', title: 'First Name' },
                { value: 'Email', title: 'Email' },
            ],
            ai_request: (request, respondWith) => respondWith.string(() => Promise.reject("See docs to implement AI Assistant"))
        });
</script>
   </head>
<body>
    
<!-- Place the following <script> and <textarea> tags your HTML's <body> -->



    <div class="container mt-3">
<a href="index.php" class="btn btn-primary my-5">Dashboard</a>
<a href="mypages.php" class="btn btn-primary my-5">All pages</a>
<a href="posts.php" class="btn btn-primary my-5">All posts</a>


        <h2>Create a New Page</h2>
        <form id="createPageForm" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST" enctype="multipart/form-data">
            <div class="form-group">
                <label for="title">Page Title</label>
                <input type="text" class="form-control" id="title" name="title" required>
            </div>
            <!-- Other form fields -->
            <div class="row mb-3">
               
                <div class="col mt-3">
                    <label for="meta_desc">Meta Description</label>
                    <input id="meta_desc" name="meta_desc" class="form-control" type="text" placeholder="Enter meta description" aria-label="default input example">
                </div>
            </div>
            <div class="row mb-3">
                <div class="col mt-3">
                    <label for="meta_Keywords">Meta Keywords</label>
                    <input id="meta_Keywords" name="meta_Keywords" class="form-control" type="text" placeholder="Enter meta keywords" aria-label="default input example">
                </div>
                <div class="col mt-3">
                    <label for="meta_cronical">Meta Cronical</label>
                    <input id="meta_cronical" name="meta_cronical" class="form-control" type="text" placeholder="Enter meta cronical" aria-label="default input example">
                </div>
            </div>
            <div class="row mb-3">
                <div class="col">
                    <label for="date">Date</label>
                    <input id="date" name="date" class="form-control" type="date" aria-label="default input example" required>
                </div>
                <div class="col">
                    <div class="mb-3">
                        <label for="design">Select Design</label>
                        <select id="design" name="design" class="form-select me-2" required>
                            <option value="Design_1">Parent Page</option>
                            <option value="Design_2">Full Width Template</option>
                            <option value="Design_3">Child full width</option>
                            <!-- <option value="Design_4">child template with right side bar</option> -->

                        </select>
                    </div>
                </div>
                
            </div>
            <div class="form-group">
                <label for="slug">Slug</label>
                <input type="text" class="form-control" id="slug" name="slug" required>
            </div>
            <div id="parentField" class="form-group" style="display: none;">
                <label for="parent_id">Parent ID (optional)</label>
                <input type="number" class="form-control" id="parent_id" name="parent_id">
            </div>
            <div class="form-check mb-3">
                <input type="checkbox" class="form-check-input" id="isChildPage">
                <label class="form-check-label" for="isChildPage">Create as Child Page</label>
            </div>
            <h2 class="text-center fw-bolder mt-4">Page Description</h2>
            <div class="mb-3">
                <label for="formFile" class="form-label">Image</label>
                <input name="image" class="form-control" type="file" id="formFile" accept=".png, .jpg, .jpeg" required>
            </div>
            <textarea id="content" name="content">Hello, World!</textarea>
            <button type="submit" class="btn btn-primary">Create Page</button>
        </form>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script>
        document.getElementById('isChildPage').addEventListener('change', function() {
            var parentField = document.getElementById('parentField');
            if (this.checked) {
                parentField.style.display = 'block';
            } else {
                parentField.style.display = 'none';
            }
        });

      

       
</script>
</body>
</html>

