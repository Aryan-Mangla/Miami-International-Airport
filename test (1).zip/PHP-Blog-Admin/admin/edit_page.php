<?php
require_once "functions/myconfig.php";

// Check if the ID is set and is a valid number
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die("Invalid page ID.");
}

$page_id = $_GET['id'];

// Retrieve the page details
$sql = "SELECT * FROM pages WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $page_id);
$stmt->execute();
$result = $stmt->get_result();
$page = $result->fetch_assoc();

if (!$page) {
    die("Page not found.");
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = $_POST['title'];
    $content = $_POST['content'];
    $slug1 = $_POST['slug'];
    $slug = strtolower($slug1);
  
    $meta_desc = $_POST['meta_desc'];
    $meta_keywords = $_POST['meta_Keywords'];
    $meta_cronical = $_POST['meta_cronical'];
    $date = $_POST['date'];
    $design = $_POST['design'];
    
    $parent_id = !empty($_POST['parent_id']) ? (int)$_POST['parent_id'] : null;
    $image = $page['image']; // Default to existing image
    
    // Handle file upload
    if (isset($_FILES['image']) && $_FILES['image']['error'] == UPLOAD_ERR_OK) {
        $target_dir = "../../Pic/uploaded/";
        $target_db = "/airlines/Pic/uploaded/";
        $target_file = $target_dir . basename($_FILES["image"]["name"]);
        $target_file_db = $target_db . basename($_FILES["image"]["name"]);

        if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
            $image = $target_file_db;
        } else {
            echo "Sorry, there was an error uploading your file.";
        }
    }

    // Update the page in the database
    $sql = "UPDATE pages SET title = ?, content = ?, parent_id = ?, slug = ?, meta_desc = ?, meta_keywords = ?, meta_cronical = ?, date = ?, design = ?, image = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssisssssssi", $title, $content, $parent_id, $slug, $meta_desc, $meta_keywords, $meta_cronical, $date, $design, $image, $page_id);

    if ($stmt->execute()) {
        header("Location: mypages.php?=success");
        exit();
    } else {
        echo "Error updating record: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Page</title>
    <link rel="stylesheet" href="bootstrap.min.css">
    <script src="https://cdn.tiny.cloud/1/ebs4evfkr4f8epp30mmtuelc8xqoiktmffjcg8sr6zt11ibd/tinymce/7/tinymce.min.js" referrerpolicy="origin"></script>
    <script src="column-plugin.js"></script> 

<script>
    tinymce.init({
      selector: 'textarea',
      plugins: 'anchor autolink charmap codesample emoticons image link lists media searchreplace table visualblocks wordcount bootstrap_columns', // Make sure your custom plugin is included here
      toolbar: 'two_col three_col | undo redo | blocks fontfamily fontsize | bold italic underline strikethrough | link image media table mergetags | addcomment showcomments | spellcheckdialog a11ycheck typography | align lineheight | checklist numlist bullist indent outdent | emoticons charmap | removeformat',
      tinycomments_mode: 'embedded',
      tinycomments_author: 'Author name',
      mergetags_list: [
        { value: 'First.Name', title: 'First Name' },
        { value: 'Email', title: 'Email' },
      ],
      ai_request: (request, respondWith) => respondWith.string(() => Promise.reject("See docs to implement AI Assistant"))
    });
  </script>
</head>
<body>
    <div class="container mt-5">
        <h2>Edit Page</h2>
        <form id="editPageForm" action="edit_page.php?id=<?php echo $page_id; ?>" method="POST" enctype="multipart/form-data">
            <div class="form-group">
                <label for="title">Page Title</label>
                <input type="text" class="form-control" id="title" name="title" value="<?php echo htmlspecialchars($page['title']); ?>" required>
            </div>
            <!-- Other form fields -->
            <div class="row mb-3">
               
                <div class="col mt-3">
                    <label for="meta_desc">Meta Description</label>
                    <input id="meta_desc" name="meta_desc" class="form-control" type="text" value="<?php echo htmlspecialchars($page['meta_desc']); ?>" placeholder="Enter meta description" aria-label="default input example">
                </div>
            </div>
            <div class="row mb-3">
                <div class="col mt-3">
                    <label for="meta_Keywords">Meta Keywords</label>
                    <input id="meta_Keywords" name="meta_Keywords" class="form-control" type="text" value="<?php echo htmlspecialchars($page['meta_Keywords']); ?>" placeholder="Enter meta keywords" aria-label="default input example">
                </div>
                <div class="col mt-3">
                    <label for="meta_cronical">Meta Cronical</label>
                    <input id="meta_cronical" name="meta_cronical" class="form-control" type="text" value="<?php echo htmlspecialchars($page['meta_cronical']); ?>" placeholder="Enter meta cronical" aria-label="default input example">
                </div>
            </div>
            <div class="row mb-3">
                <div class="col">
                    <label for="date">Date</label>
                    <input id="date" name="date" class="form-control" type="date" value="<?php echo htmlspecialchars($page['date']); ?>" aria-label="default input example" required>
                </div>
                <div class="col">
                    <div class="mb-3">
                        <label for="design">Select Design</label>
                        <select id="design" name="design" class="form-select me-2" required>
                            <option value="Design_1" <?php if ($page['design'] == 'Design_1') echo 'selected'; ?>>Parent Page</option>
                            <option value="Design_2" <?php if ($page['design'] == 'Design_2') echo 'selected'; ?>>Full Width Template</option>
                            <option value="Design_3" <?php if ($page['design'] == 'Design_3') echo 'selected'; ?>>Child full width</option>
                            <!-- <option value="Design_4">child template with right side bar</option> -->
                        </select>
                    </div>
                </div>
            </div>
            <div class="form-group">
                <label for="slug">Slug</label>
                <input type="text" class="form-control" id="slug" name="slug" value="<?php echo htmlspecialchars($page['slug']); ?>" required>
            </div>
            <div id="parentField" class="form-group" style="display: <?php echo $page['parent_id'] !== null ? 'block' : 'none'; ?>;">
                <label for="parent_id">Parent ID (optional)</label>
                <input type="number" class="form-control" id="parent_id" name="parent_id" value="<?php echo htmlspecialchars($page['parent_id']); ?>">
            </div>
            <div class="form-check mb-3">
                <input type="checkbox" class="form-check-input" id="isChildPage" <?php if ($page['parent_id'] !== null) echo 'checked'; ?>>
                <label class="form-check-label" for="isChildPage">Create as Child Page</label>
            </div>
            <h2 class="text-center fw-bolder mt-4">Page Description</h2>
            <div class="mb-3">
                <label for="formFile" class="form-label">Image</label>
                <input name="image" class="form-control" type="file" id="formFile" accept=".png, .jpg, .jpeg">
                <img src="<?php echo htmlspecialchars($page['image']); ?>" alt="Current Image" style="max-width: 100px; max-height: 100px;">
            </div>
            <textarea id="content" name="content"><?php echo htmlspecialchars($page['content']); ?></textarea>
            <button type="submit" class="btn btn-primary">Update Page</button>
        </form>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script>
        document.getElementById('isChildPage').addEventListener('change', function() {
            var parentField = document.getElementById('parentField');
            if (this.checked) {
                parentField.style.display = 'block';
            } else {
                parentField.style.display = 'none';
            }
        });
    </script>
</body>
</html>

<?php
$stmt->close();
$conn->close();
?>
