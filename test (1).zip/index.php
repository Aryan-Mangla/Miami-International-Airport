
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Atlanta Airlines</title>
    <link rel="stylesheet" href="bootstrap.min.css">
    <link rel="stylesheet" href="style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    <script src="path/to/jquery.easing.1.3.js"></script>
  
</head>
    
<body style="overflow-x: hidden;">

    <?php 
    require_once 'config.php'; 
    include 'header.php';

    ?>
    
<?php
// Function to generate page URL
function generatePageUrl($page_id) {
    global $conn;

    $segments = [];
    $current_id = $page_id;

    while ($current_id !== null) {
        $stmt = $conn->prepare("SELECT slug, parent_id FROM pages WHERE id = ?");
        $stmt->bind_param("i", $current_id);
        $stmt->execute();
        $stmt->bind_result($slug, $parent_id);
        $stmt->fetch();
        $segments[] = $slug;
        $current_id = $parent_id;
        $stmt->close();
    }

    $segments = array_reverse($segments);
    return implode('/', $segments);
}
?>
    <!-- Atlanta Banner -->
    <div class="card rounded-0 position-relative" >
        <img src="Pic/Atlanta-banner.png" class="card-img" style="height:33em;" alt="Atlanta-airlines">
    </div>
    <!-- Atlanta Banner End -->
    
<!-- Arrival & Departure -->
    <div class="container search-container my-5 position-relative pos132">
    <h2 class="fw-bolder fs-2 mb-4">Flight Info</h2>
    <!-- Navigation Tabs -->
    <ul class="nav nav-tabs" id="flightInfoTabs" role="tablist">
        <li class="nav-item">
            <a class="nav-link theme-color active" id="departure-tab" data-toggle="tab" href="#departure" role="tab" aria-controls="departure" aria-selected="true">Departure</a>
        </li>
        <li class="nav-item">
            <a class="nav-link theme-color" id="arrival-tab" data-toggle="tab" href="#arrival" role="tab" aria-controls="arrival" aria-selected="false">Arrival</a>
        </li>
        <li class="nav-item">
            <a class="nav-link theme-color" id="connections-tab" data-toggle="tab" href="#connections" role="tab" aria-controls="connections" aria-selected="false">Connections</a>
        </li>
    </ul>

    <!-- Search Bar Container -->
    <div class="container mt-4">
        <div class="input-group">
            <input type="text" id="commonSearchBar" class="form-control" placeholder="Search for departures...">
            <div class="input-group-append">
                <button class="btn theme-bg text-light" type="button">Search</button>
            </div>
        </div>
    </div>
    <a id="more-link" class="btn theme-bg text-light m-3" href="flights-departures">More</a>
</div>

<?php
function truncateText($text, $maxLength = 100) {
    $text = strip_tags($text);
    if (strlen($text) > $maxLength) {
        $text = substr($text, 0, $maxLength) . '...';
    }
    return $text;
}
?>

<!-- website link https://www.flightradar24.com/data/airports/atl -->
<!-- Arrival & Departure End-->

<!-- Terminals -->
<?php
$ids = [16, 17, 18];

$id_placeholders = implode(',', array_fill(0, count($ids), '?'));
$stmt = $conn->prepare("SELECT * FROM pages WHERE id IN ($id_placeholders)");

$types = str_repeat('i', count($ids));  // 'i' for integer type
$stmt->bind_param($types, ...$ids);
$stmt->execute();
$result = $stmt->get_result();

$pages = [];
while ($row = $result->fetch_assoc()) {
    $pages[] = $row;
}

$stmt->close();
?>
 <section class="container  bg-body-tertiary">
    <h2 class="fw-bolder fs-2 text-center">Terminals</h2>
    <p class="text-center mb-4">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quae nostrum vero quidem obcaecati quis itaque doloribus quod expedita dignissimos sapiente, dolor possimus aspernatur dolorum rem quasi maxime! Obcaecati molestias dolore cumque. Similique repudiandae excepturi, libero non beatae, vero illo quia eveniet delectus tenetur soluta eos, nulla error laboriosam. Maxime, totam.</p>

       
        <div class="row">
            <?php foreach ($pages as $page): 
                        $truncatedterminal = truncateText($page['content'], 100);?>
                <div class="col-md-4 mb-4">
                    <a href="<?php echo htmlspecialchars($page['slug']); ?>" class="terminal-item" style="background-image: url('<?php echo htmlspecialchars($page['image']); ?>');">
                        <div class="terminal-item-content d-flex justify-content-center align-items-center">
                            <div class="">
                                <h5 class="terminal-item-title text-center"><?php echo htmlspecialchars($page['title']); ?></h5>
                                <p  class="terminal-item-description text-center"><?php echo $truncatedterminal; ?></p>                            
                            </div>    
                        </div>
                    </a>
                </div>
            <?php endforeach; ?>
        </div>
    </section>
<!-- Terminals end -->

<!-- Transportation Section -->
<?php 

// IDs for Transportation
$transportation_ids = [19, 20, 21,22];

$id_placeholders = implode(',', array_fill(0, count($transportation_ids), '?'));
$stmt = $conn->prepare("SELECT * FROM pages WHERE id IN ($id_placeholders)");

$types = str_repeat('i', count($transportation_ids));  // 'i' for integer type
$stmt->bind_param($types, ...$transportation_ids);
$stmt->execute();
$result = $stmt->get_result();

$transportation_pages = [];
while ($row = $result->fetch_assoc()) {
    $transportation_pages[] = $row;
}

$stmt->close();


?>
<div class="container-fluid  p-4">
    <section class="container my-5">
    <h2 class="fw-bolder fs-2 text-center">Transportation</h2>
    <p class="text-center mb-4">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quae nostrum vero quidem obcaecati quis itaque doloribus quod expedita dignissimos sapiente, dolor possimus aspernatur dolorum rem quasi maxime! Obcaecati molestias dolore cumque. Similique repudiandae excepturi, libero non beatae, vero illo quia eveniet delectus tenetur soluta eos, nulla error laboriosam. Maxime, totam.</p>

        <div class="row">
            <?php foreach ($transportation_pages as $page):  $truncatedtransport = truncateText($page['content'], 100);?>
                <div class="col-md-4 mb-4">
                    <a href="<?php echo htmlspecialchars($page['slug']); ?>" class="transport-item" style="background-image: url('<?php echo htmlspecialchars($page['image']); ?>');">
                        <div class="transport-item-content d-flex justify-content-center align-items-center">
                            <div class="">
                                <h5 class="transport-item-title"><?php echo htmlspecialchars($page['title']); ?></h5>
                                <p  class="transport-item-description"><?php echo $truncatedtransport; ?></p>
                            </div>
                        </div>
                    </a>
                </div>
            <?php endforeach; ?>
        </div>
    </section>
</div>


<!-- Transportation Section End -->

<!-- Other Facilities -->
<div class="container my-5">
    <h2 class="fw-bolder fs-2 text-center">Other Services</h2>
    <p class="text-center mb-4">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quae nostrum vero quidem obcaecati quis itaque doloribus quod expedita dignissimos sapiente, dolor possimus aspernatur dolorum rem quasi maxime! Obcaecati molestias dolore cumque. Similique repudiandae excepturi, libero non beatae, vero illo quia eveniet delectus tenetur soluta eos, nulla error laboriosam. Maxime, totam.</p>

        <div class="row">
            <div class="col-md-4">
                <a href="parking" class="service-card d-block">
                    <div class="icon"><i class="fas fa-parking"></i></div>
                    <div>Parking</div>
                </a>
            </div>
            <div class="col-md-4">
                <a href="customer-service" class="service-card d-block">
                    <div class="icon"><i class="fas fa-info-circle"></i></div>
                    <div>Customer services</div>
                </a>
            </div>
            <div class="col-md-4">
                <a href="amenities-services" class="service-card d-block">
                    <div class="icon"><i class="fas fa-concierge-bell"></i></div>
                    <div>Amenities-Services</div>
                </a>
            </div>
        </div>
        <div class="row">
            <div class="col-md-4">
                <a href="hotels" class="service-card d-block">
                    <div class="icon"><i class="fas fa-hotel"></i></div>
                    <div>Hotels</div>
                </a>
            </div>
            <div class="col-md-4">
                <a href="lounges" class="service-card d-block">
                    <div class="icon"><i class="fas fa-lounge"></i></div>
                    <div>Lounge</div>
                </a>
            </div>
            <div class="col-md-4">
                <a href="shops" class="service-card d-block">
                    <div class="icon"><i class="fas fa-shopping-cart"></i></div>
                    <div>Shop</div>
                </a>
            </div>
        </div>
    </div>

<!-- Other Facilities End-->

<!-- Contact Section -->
<div class="container my-5">
             <h2 class="fw-bolder fs-2 text-center my-2">Follow Us</h2>
             <p class="text-center mb-4">Lorem ipsum dolor sit amet, consectetur adipisicing elit..</p>
    <div class="row">
        <div class="col-md-6">
            
            <div class="contact-info p-4">
                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-4 text-center">
                            <div class="row justify-content-center">
                                <i class="fas fa-map-marker-alt fa-2x mb-3" style="font-size:5em;"></i>
                            </div>
                            <div class="d-inline-block align-middle">
                                <p class="font-weight-bold mb-1">ADDRESS:</p>
                                <p>121 Rock Street, 21 Avenue,<br>New York, NY 92103-9000</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-4 text-center">
                            <div class="row justify-content-center">
                                <i class="fas fa-envelope fa-2x mb-3" style="font-size:5em;"></i>
                            </div>
                            <div class="d-inline-block align-middle">
                                <p class="font-weight-bold mb-1">EMAIL:</p>
                                <p class="mb-0"><a href="mailto:hello@company.com" class="text-decoration-none">hello@company.com</a></p>
                                <p class="mb-0"><a href="mailto:support@company.com" class="text-decoration-none">support@company.com</a></p>
                            </div>
                        </div>
                    </div>
                </div>      

                <div class="row">
                   
                    <div class="col-md-6">
                        <div class="mb-4 text-center">
                            <div class="row justify-content-center text-center">
                            <i class="fas fa-phone-alt fa-2x mb-3 text-center" style="font-size:4em;"></i>
                            </div>
                            <div class="row ">
                            <div class="d-inline-block align-middle">
                            <p class="font-weight-bold mb-1">CALL US:</p>
                                <p class="mb-0">1 (234) 567-891</p>
                                <p class="mb-0">1 (234) 987-654</p>
                            </div>
                            </div>
                          
                           
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-4 text-center" > 
                            <div class=" justify-content-center ">
                                <i class="fas fa-info-circle fa-2x mb-3" style="font-size:4em;"></i>
                            </div>
                            <div class="d-inline-block align-middle">
                                <p class="font-weight-bold mb-1">CONTACT US:</p>
                                <p>Contact us for a quote. Help or to join the team.</p>
                                <p class="d-flex justify-content-evenly">
                                    <a href="#" class="mr-2" style="font-size:1.5em;"><i class="fab fa-facebook-f"></i></a>
                                    <a href="#" class="mr-2" style="font-size:1.5em;"><i class="fab fa-twitter"></i></a>
                                    <a href="#" class="mr-2" style="font-size:1.5em;"><i class="fab fa-instagram"></i></a>
                                    <a href="#" class="mr-2" style="font-size:1.5em;"><i class="fab fa-pinterest"></i></a>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6">


            <div class="embed-responsive embed-responsive-16by9">
                <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d9725.909422940034!2d-1.7435093!3d52.4523818!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4870b0deff56c9e3%3A0xd7fab23579355bb!2sBirmingham%20Airport!5e0!3m2!1sen!2sus!4v1696392401331!5m2!1sen!2sus" width="100%" height="510" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
            </div>
        </div>
    </div>
</div>

<!-- Contact Section End -->
<!-- Blogs -->
<div class="container my-5">
    <h2 class="fw-bolder fs-3 text-center">Our Latest <span class="theme-color">Blogs</span></h2>
    <p class="text-center my-4">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quae nostrum vero quidem obcaecati quis itaque doloribus quod expedita dignissimos sapiente, dolor possimus aspernatur dolorum rem quasi maxime! Obcaecati molestias dolore cumque. Similique repudiandae excepturi, libero non beatae, vero illo quia eveniet delectus tenetur soluta eos, nulla error laboriosam. Maxime, totam.</p>
    <div class="row g-4">
        <?php
        // Retrieve the parent page ID of "Our Blogs"
        $parentPageTitle = "Our Blogs"; // Update with the title of the parent page
        $parentPageId = null;

        $parentPageStmt = $conn->prepare("SELECT id FROM pages WHERE title = ?");
        $parentPageStmt->bind_param("s", $parentPageTitle);
        $parentPageStmt->execute();
        $parentPageStmt->bind_result($parentPageId);
        $parentPageStmt->fetch();
        $parentPageStmt->close();

        if ($parentPageId) {
            // Parent page ID found, query the database for child pages ordered by date
            $childPagesStmt = $conn->prepare("SELECT * FROM pages WHERE parent_id = ? ORDER BY date DESC LIMIT 5");
            $childPagesStmt->bind_param("i", $parentPageId);
            $childPagesStmt->execute();
            $childPagesResult = $childPagesStmt->get_result();

            // Display the child pages
            $count = 0; // Initialize a counter for the number of child pages displayed
            if ($childPagesResult->num_rows > 0) {
                while ($childPageRow = $childPagesResult->fetch_assoc()) {
                    if ($count == 0) {
                        $truncatedContent = truncateText($childPageRow['content'], 150);
                        $truncatedContentsmall = truncateText($childPageRow['content'], 90);

                        // Display the latest blog in col-md-7
                        ?>
                        <div class="col-md-6">
                            <a href="<?php echo generatePageUrl($childPageRow['id']); ?>" class="text-decoration-none text-dark">
                                <div class="card h-100 border-0">
                                    <img src="<?php echo $childPageRow['image']; ?>" class="card-img-top rounded-4" alt="...">
                                    <div class="card-body">

                                        <h5 class="card-title fs-1"><?php echo $childPageRow['title']; ?></h5>
                                    <small class="badge theme-bg my-2"><?php echo $childPageRow['date']; ?></small>
                                        <p class="fs-6"><?php echo $truncatedContent; ?></p>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <?php
                    } else {
                        // Display the next four latest blogs in col-md-5
                        if ($count == 1) {
                            echo '<div class="col-md-6">';
                        }
                        ?>
                       <div class="row rounded-4 mb-4">
                            <div class="col-md-5">
                                <a href="<?php echo generatePageUrl($childPageRow['id']); ?>" class="text-decoration-none text-dark">
                                    <div class="card rounded-4">
                                        <img src="<?php echo $childPageRow['image']; ?>" class="card-img-top rounded-4" style="height:8.5em;" alt="...">
                                    </div>
                                </a>
                            </div>
                            <div class="col-md-7">
                                <a href="<?php echo generatePageUrl($childPageRow['id']); ?>" class="text-decoration-none text-dark">
                                    <div class="card-body">
                                        <h5 class="card-title"><?php echo $childPageRow['title']; ?></h5>
                                        <small class="badge theme-bg "><?php echo $childPageRow['date']; ?></small>
                                        <p class="fs-6 my-2"><?php echo $truncatedContentsmall; ?></p>


                                    </div>
                                </a>
                            </div>
                        </div>
                        <?php
                        if ($count == 4) {
                            echo '</div>';
                        }
                    }
                    $count++;
                }
            } else {
                echo "<p>No child pages found for Our Blogs.</p>";
            }
            $childPagesStmt->close();
        } else {
            echo "<p>Parent page 'Our Blogs' not found.</p>";
        }
        ?>
    </div>
</div>

    
    <!-- "Read more" button -->
    <div class="row mt-4">
        <div class="col text-center">
            <a href="<?php echo generatePageUrl($parentPageId); ?>" class="btn theme-bg text-light">Read more</a>
        </div>
    </div>
</div>

<!-- Blogs End -->
<!-- Subscribe -->
<div class="container text-center mt-5">
        <div class="row">
            <div class="col-md-6 offset-md-3">
                <h2>Subscribe Us</h2>
                <form id="subscribeForm" action="subscribe.php" method="post">
                    <div class="form-group">
                        <input type="email" name="email" class="form-control" placeholder="Enter your email" required>
                    </div>
                    <button type="submit" class="btn theme-bg text-light my-3">Subscribe</button>
                </form>
            </div>
        </div>
    </div>
   
 <!-- Subscribe end -->
<?php include 'footer.php'; ?>

 <!-- Font Awesome JS -->
 <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/js/all.min.js"></script>
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>    
 <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.min.js" integrity="sha384-cuYeSxntonz0PPNlHhBs68uyIAVpIIOZZ5JqeqvYYIcEL727kskC66kF92t6Xl2V" crossorigin="anonymous"></script>
 <!-- jQuery and Bootstrap JS -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <script>
        $(document).ready(function() {
            // Define the placeholders for each tab
            const placeholders = {
                'departure': 'Search for departures...',
                'arrival': 'Search for arrivals...',
                'connections': 'Search for connections...'
            };

            // Define the href values for each tab
            const hrefValues = {
                'departure': 'flights-departures',
                'arrival': 'flights-arrivals',
                'connections': 'flights-connections'
            };

            // Handle tab switch
            $('#flightInfoTabs a').on('shown.bs.tab', function(event) {
                const target = $(event.target).attr('aria-controls'); // Get the target tab id
                $('#commonSearchBar').attr('placeholder', placeholders[target]); // Update the placeholder
                $('#more-link').attr('href', hrefValues[target]); // Update the href value
            });
        });
    </script>
</body>
</html>